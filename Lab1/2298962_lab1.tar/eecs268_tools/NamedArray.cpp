/**
 * file NamedArray.cpp
 *
 * author [Your Name]
 * date [Today's Date]
 * version 1.0
 */
#include "NamedArray.h"
using namespace std;

NamedArray::NamedArray(int aSize, string aName)
{
  name = aName;
  size = aSize;
  array = new int[size];
  for(int i=0;i<size;i++)
  {
    array[i] = i;
  }
}

NamedArray::~NamedArray()
{
  delete [] array;
  array = NULL;
}

int NamedArray::getValue(int i)
{
  int localVariable = -1;
  if((i >= 0) && (i < size))
    localVariable = array[i];
  return localVariable;
}

void NamedArray::printArray()
{
  cout << name << endl;
  for(int i=0;i<size;i++)
    cout << array[i] << " ";
  cout << endl;
}



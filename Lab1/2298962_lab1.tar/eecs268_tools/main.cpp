/**
 * file main.cpp
 *
 * author [Your Name]
 * date [Today's Date]
 * version 1.0
 */
#include <iostream>
#include "NamedArray.h"
using namespace std;

void functionA();
void functionB();
void functionC();
void functionD();

int main(int argc, char *argv[])
{
  // create a NamedArray object with 5 for its size, and a name
  NamedArray anArray(5, "High Five");

  // print array
  anArray.printArray();

  // call the NamedArray object's getValue method 
  // and output the result to cout
  cout << anArray.getValue(3) << endl;

  // call the NamedArray object's getValue method with invalid value
  // and output the result to cout
  cout << anArray.getValue(99) << endl;

  functionA();
  functionC();
  functionD();

  return 0;
}

void functionA()
{
  cout << "This is function A" << endl;
  functionB();
}

void functionB()
{
  cout << "This is function B" << endl;
  cout << "This is an example for ddd up/down" << endl;
}

void functionC()
{
  cout << "This is function C" << endl;
  cout << "This is another example" << endl;
}

void functionD()
{
  cout << "Name: Elise McEllhiney" << endl;
  cout << "Major: Computer Engineering" << endl;
  cout << "I don't know what else to say" << endl;
}


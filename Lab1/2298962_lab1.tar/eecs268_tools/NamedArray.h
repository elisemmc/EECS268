/**
 * file NamedArray.h
 *
 * author [Your Name]
 * date [Today's Date]
 * version 1.0
 */
#include <iostream>
#include <string>
/**
  * Holds a dynamically allocated array associated with a particular name
*/
class NamedArray
{
  public:
    /**
     * NamedArray constructor
     * param aSize - integer indicating the size to make the array
     * param aName - name to give the array
     * pre: none
     * post: the instance of NamedArray will contain a dynamically 
     *       allocated array of size aSize with a name of aName.
     */
    NamedArray(int aSize=1, std::string aName="default");
    /**
     * NamedArray destructor
     * param aSize - integer indicating the size to make the array
     * param aName - name to give the array
     * pre: none
     * post: the instance of NamedArray will contain a 
     *       dynamically allocated array of size aSize with 
     *       a name of aName.
     * return void
     */
    ~NamedArray();
    /**
     * getValue
     * param i - index of value of array that will be returned
     * pre: array exists.
     * post: none
     * return: integer value stored at position i of the array.  
     *         If i is out of range, -1 is returned
     */
    int getValue(int i);
    /**
     * printArray
     * pre: array exists.
     * post: the contents of the array as well as its name 
     *       are printed to standard out.
     * return: void
     */
    void printArray();
    
  private:
    int size;
    std::string name;
    int * array;
 };


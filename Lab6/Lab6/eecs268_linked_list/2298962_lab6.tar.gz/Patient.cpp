/**Patient.cpp*/

#include "Patient.h"
#include <iostream>

using namespace std;

Patient::Patient(string first, string last, int Age, string Ailment){
  firstname = first;
  lastname = last;
  age = Age;
  ailment = Ailment;
}

void Patient::print(){
  cout << firstname << " " << lastname << ", " << age << " - " << ailment << "\n";
}

